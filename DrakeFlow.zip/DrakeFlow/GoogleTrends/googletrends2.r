#install.packages("renv")
#install.packages("gtrendsR")
#install.packages("reshape2")
#install.packages("tidyverse")
#install.packages("tidyr")
#install.packages("foreach")
#install.packages("parallel")
#install.packages("doParallel")
#install.packages("data.table")
.libPaths()

#If you want to add keywords to the data pull, add them in the csv from this directory


library(gtrendsR)
library(reshape2)
library(tidyverse)
library(tidyr)
library(foreach)
library(parallel)
library(doParallel)
library(data.table)

#This detects cores (or logical processors on newer AMD cpu's)
cores <- detectCores()-4
#this registers the cores for doing parallel work with foreach()
#registerDoParallel(cores)

#setwd("~")
#getwd()
#setwd("C:/Users/yjames/NetApp Inc/Forecast bookings core - Documents/sandbox/investigations/summer-2020/James/GoogleTrends")
#This reads in the data from the project directory. may switch to here() format
keywordscsv <- read.csv(here::here("GoogleTrends/GoogleTrendsKeywords.csv"))
#Making sure the keyword list is in proper format for gtrendsr()
keywordscsv <- keywordscsv[,1] %>%
                as.character() %>%
                as.list()


#Below we will pull google trends from the internet as a loop because 
#the gtrends() function doesn't like doing more than 5 at a time.
#Highlight lines 35 through 43 and run as a group w/ ctrl+enter
tsGtrends <- NULL
start_time <- Sys.time()
tsGtrends <- foreach(i=1:length(keywordscsv), .combine=cbind) %do% { #%dopar% is parallel in foreach() and %do% is sequential
  library(gtrendsR)
  library(reshape2)
  g <- gtrends(keywordscsv[i], gprop = "web", time = "2014-01-01 2015-07-07")[[1]] #"all"
  g$hits
  }
end_time <- Sys.time()
paralleltime <- start_time - end_time
#Below we can find the time it took to complete
paralleltime
g <- gtrends(keywordscsv[3], gprop = "web", time = "2014-01-01 2015-07-07")[[1]] #"all"

#########################################################
#clean the data

#Clean up the data by adding the date to the index, and correcting
#the column names.
#these 2 lines add date to index
tsGtrends <- as.data.frame(tsGtrends) 
rownames(tsGtrends) = g$date

#take the column names and match to keyword list by its index
#if any keywords were not returned, this will adjust for it
#by skipping their name in the column names.
names <- gsub("result.", "", colnames(tsGtrends)) %>%
         as.numeric() %>%
         as.data.frame()
colnames(names) <- "number"
a <- as.data.frame(keywordscsv) %>%
  t() %>%
  as.data.frame()
a$number <- 1:nrow(a)
#names$number <- 1:nrow(names)
colnames(tsGtrends) <- merge(a, names, by = "number")[,2]

#tsGtrends now has the correct column names accounting for 
#any chance that a keyword was not added to the dataframe

############################################################

                      
tsGtrends <- setDT(tsGtrends, keep.rownames = TRUE)[]
tsGtrends <- as.data.frame(tsGtrends)

for(i in 2:ncol(tsGtrends)) {tsGtrends[,i] = as.numeric(tsGtrends[,i])}

colnames(tsGtrends)[1] <- "Date"
tsGtrends$Date <- as.Date(tsGtrends$Date)

write.csv(tsGtrends, file="tsGtrendsOlder.csv")


tsGtrends2 <- tsGtrends


#Below we will pull google trends from the internet as a loop because 
#the gtrends() function doesn't like doing more than 5 at a time.
#Highlight lines 35 through 43 and run as a group w/ ctrl+enter
tsGtrends <- NULL
start_time <- Sys.time()
tsGtrends <- foreach(i=1:length(keywordscsv), .combine=cbind) %do% { #%dopar% is parallel in foreach() and %do% is sequential
  library(gtrendsR)
  library(reshape2)
  g <- gtrends(keywordscsv[i], gprop = "web", time = "2015-07-05 2020-07-07")[[1]] #"all"
  g$hits
}
end_time <- Sys.time()
paralleltime <- start_time - end_time
#Below we can find the time it took to complete
paralleltime
g <- gtrends(keywordscsv[3], gprop = "web", time = "2015-07-05 2020-07-07")[[1]] #"all"

#########################################################
#clean the data

#Clean up the data by adding the date to the index, and correcting
#the column names.
#these 2 lines add date to index
tsGtrends <- as.data.frame(tsGtrends) 
rownames(tsGtrends) = g$date

#take the column names and match to keyword list by its index
#if any keywords were not returned, this will adjust for it
#by skipping their name in the column names.
names <- gsub("result.", "", colnames(tsGtrends)) %>%
  as.numeric() %>%
  as.data.frame()
colnames(names) <- "number"
a <- as.data.frame(keywordscsv) %>%
  t() %>%
  as.data.frame()
a$number <- 1:nrow(a)
#names$number <- 1:nrow(names)
colnames(tsGtrends) <- merge(a, names, by = "number")[,2]

#tsGtrends now has the correct column names accounting for 
#any chance that a keyword was not added to the dataframe

############################################################


tsGtrends <- setDT(tsGtrends, keep.rownames = TRUE)[]
tsGtrends <- as.data.frame(tsGtrends)

for(i in 2:ncol(tsGtrends)) {tsGtrends[,i] = as.numeric(tsGtrends[,i])}

colnames(tsGtrends)[1] <- "Date"
tsGtrends$Date <- as.Date(tsGtrends$Date)

write.csv(tsGtrends, file="tsGtrendsWeekly.csv")


tsGtrends2 <- tsGtrends
