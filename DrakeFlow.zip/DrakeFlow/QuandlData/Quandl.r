.libPaths()
#install.packages("Quandl")


library(Quandl)
library(parallel)
library(doParallel)
library(foreach)

#This detects cores (or logical processors on newer AMD cpu's)
cores <- detectCores()
#this registers the cores for doing parallel work with foreach()
registerDoParallel(cores)

#This reads in the data from the project directory. may switch to here() format
qcode <- read.csv(here::here("QuandlData/QuandlCodes.csv"))
#Making sure the keyword list is in proper format for quandl()
qcode <- qcode[,1] %>%
  as.character() %>%
  as.list()



Quandl.api_key('xh8BufDtg2aUgkBhi3sk')

#Below we will pull google trends from the internet as a loop because 
#the gtrends() function doesn't like doing more than 5 at a time.
#Highlight lines 35 through 43 and run as a group w/ ctrl+enter
start_time <- Sys.time()
tsQuandl <- foreach(i=1:length(qcode)) %do% { #%dopar% is parallel in foreach() and %do% is sequential
  library(Quandl)
  #The api key needs to be in here otherwise it will limit calls
  Quandl.api_key('xh8BufDtg2aUgkBhi3sk')
  Quandl(as.character(qcode[i]))
  
}
end_time <- Sys.time()
paralleltime <- start_time - end_time
#Below we can find the time it took to complete
paralleltime

#Here we merge the Quandl items by Date to get them all in one df
merged = tsQuandl[1]
for (i in 2:length(tsQuandl)) {
  a <- as.data.frame(tsQuandl[i])
  colnames(a) <- paste(i, colnames(a), sep = "_")
  colnames(a)[1] <- "Date"
  merged = merge(merged, a, by = "Date", all = T)
  merged
}

#Rename it
tsQuandl <- merged

#Write to .csv, move it up one folder level for compileAll.r
write.csv(tsQuandl, file = "tsQuandl.csv")
