#Install packages as necessary then run these lines sequentially
library(visNetwork)
library(drake)
library(here)
library(downloader)
library(tidyverse)
library(tidyquant)
library(here)
library(tidyr)
library(Quandl)
library(foreach)
library(plyr)
library(gtrendsR)
library(reshape2)
library(parallel)
library(doParallel)
library(data.table)



##The code below pulls in the scripts that are necessary to ingest
##and pre-process the data
gtrendscode <- code_to_function(here::here("GoogleTrends/googletrends2.r"))
QuandlData <- code_to_function(here::here("QuandlData/Quandl.r"))
FRED <- code_to_function("Fred/FredPrep.r")
gtrendsRectified <- code_to_function("rectifyGtrends.r")
compileData <- code_to_function("compileAll.r")



#This sets up the plan
plan <- drake_plan(
  quandlDataPulled = QuandlData(),
  gtrendsDataPulled = gtrendscode(),
  fredDataPulled = FRED(),
  gtrendsrect = gtrendsRectified(gtrendsDataPulled),
  compile = compileData(quandlDataPulled, gtrendsrect, fredDataPulled)
  
  
)

#This runs the workflow (plan) in the sequential manner you set it up.
make(plan, force = T)


vis_drake_graph(plan)






