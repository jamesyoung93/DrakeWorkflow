#tq_get

library(tidyquant)

FRED <- read.csv(here::here("FREDcodes.csv"))
FREDlist <- (as.character(FRED$Code))

df = tq_get(FREDlist[1], get = "economic.data")
colnames(df)[3] <- df[1,1]
df = df[,2:3]
for (i in 2:length(FREDlist)) {
  a <- tq_get(FREDlist[i], get = "economic.data")
  colnames(a)[3] <- a[1,1]
  a <- a[,2:3]
  df = merge(df, a, by = "date", all = T)
  
}

getwd()
write.csv(df, file = "FRED.csv")

#library(tidyr)
#df <- as.data.frame(df)
#df <- tidyr::fill(as.integer(df$CLSACBW027SBOG))


#df <- df %>% fill(-date)
