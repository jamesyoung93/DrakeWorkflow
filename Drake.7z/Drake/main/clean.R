drake::clean(destroy = TRUE)
